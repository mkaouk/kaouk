## Auto Scale

  - **payg** <br>Contains the Autoscale PAYG parent solution template.

  - **bigiq** <br> Contains the Autoscale Licensed via BIG-IQ LM parent solution template.

  - **bigip-configurations** <br> Contains various BIG-IP configuration files downloaded by the Autoscale solutions.